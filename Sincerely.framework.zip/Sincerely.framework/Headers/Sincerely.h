//
//  Sincerely.h
//  Sincerely
//
//  Created by Sincerely on 7/5/11.
//  Copyright 2013 Sincerely, Inc. All rights reserved.
//

/******************
 * Version: 1.3   *
 * Date: 05/12/13 *
 ******************/

#import <Sincerely/SincerelyConstants.h>
#import <Sincerely/SYSincerelyController.h>
