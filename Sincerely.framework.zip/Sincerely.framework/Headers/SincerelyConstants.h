//
//  SincerelyConstants.h
//  Sincerely
//
//  Created by Sincerely on 7/11/11.
//  Copyright 2013 Sincerely, Inc. All rights reserved.
//

typedef enum {
    SYProductTypePostcard
} SYProductType;
